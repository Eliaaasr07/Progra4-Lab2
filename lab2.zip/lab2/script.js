function showHobby() {
    alert('Mis hobbies favoritos son jugar fútbol y videojuegos.');
}


function showComida() {
    alert('Mis comidas favoritas son pizza, tacos y carne.');
}


function showPelicula() {
    alert('Mis películas favoritas son "Rápidos y Furiosos" y "Transformers".');
}


function showColor(event) {
    event.preventDefault(); 
    alert('Mis colores favoritos son rojo y negro.');
}


function showArtista(event) {
    if (event.key === 'Enter') {
        alert('Mi artista o deportista favorito es Cristiano Ronaldo.');
    }
}


function showPais() {
    alert('Los países que me gustaría visitar son Brasil y Japón.');
}
